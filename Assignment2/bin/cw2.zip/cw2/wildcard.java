package cw2;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class wildcard {
	public static void main (String[] args) {
		try(Scanner sc= new Scanner(System.in)){
		System.out.println("Please Enter List (Don't input the total number, use blank space between numbers):");
		String input = sc.nextLine();			
		String[] inputTokens=input.split(" ");//enter the list

		System.out.println("Please Enter Pattern:");
		int pattern = sc.nextInt();		
		sc.close();	
		int[] List = new int[inputTokens.length];
		
//		//test with regex
//		BeautifulMapPrint(TestingWithRegex(inputTokens,pattern));	//oh no it is wrong:(, cannot overlap
		
				
		for (int x=0;x<inputTokens.length; x++) {
//			System.out.println(inputTokens[x]);
			List[x]= Integer.parseInt(inputTokens[x]);
		}	
		
		int patternSize=(int)(Math.log10(pattern)+1);
		int[] inverseKeys= new int[patternSize];// create an array to store keys
		for (int x=0;x<patternSize;x++) {
			inverseKeys[x]=pattern%10;
			pattern=pattern/10;			
		}
		
		ArrayList<ArrayList<Integer>> SliceArrayList = new ArrayList<ArrayList<Integer>>();	
		FindPatterns(SliceArrayList,inverseKeys);//find all combination of patterns
		//System.out.println("SliceArrayList.size:"+SliceArrayList.size());
				
		ArrayList<Integer> location = new ArrayList<Integer>();//find the locations matching the first key of input pattern
		int firstKey = inverseKeys[inverseKeys.length-1];
		for (int x=0;x<List.length;x++) {
			if (List[x]==firstKey) {
			location.add(x); 	
			}
		}
		
		HashMap <String,Integer> results = new HashMap <String,Integer>();
		PatternAndTimes(SliceArrayList, location, List, results);
		
		System.out.println("There are "+matchTimes(results)+" matches.")	;
		System.out.print("The matches are: ");
		BeautifulMapPrint(results);		
	}
	}
	
		
	public static boolean isArrayExist( ArrayList<Integer> newList,ArrayList<ArrayList<Integer>> Slice,int w) {
		boolean Exist=false;		
			if(Slice.get(w).size()!=newList.size()) {
				Exist=false;
			}
			else {
				boolean subExist=true;
				for (int y=0;y<newList.size();y++) {
					if(Slice.get(w).get(y)!=newList.get(y)) {
						subExist=false;
						break;
					}
				}
				if(subExist=true) {
					Exist=true;
				}
			}			
		
		return Exist;//avoid adding a duplicated entry, but not that necessary as entry:value pairs will be stored in maps
	}
	
	public static void FindPatterns (ArrayList<ArrayList<Integer>> SliceArrayList, int[] inverseKeys) {
		for(int key=inverseKeys.length-1; key>=0;key--) {//find all the combinations of patterns
			if (SliceArrayList.size()==0) {
				ArrayList<Integer> tmp = new ArrayList<Integer>();
				tmp.add(inverseKeys[key]);
				SliceArrayList.add(tmp);
			}
			else {
				if(inverseKeys[key]==0) {//create new arraylist to store the entries with "0" added					
					ArrayList<ArrayList<Integer>> SliceTemp = new ArrayList<ArrayList<Integer>>();
					for(int x=0;x<SliceArrayList.size();x++){
						ArrayList<Integer> newList = new ArrayList<>(SliceArrayList.get(x));
						newList.add(0);
						SliceTemp.add(newList);
					}
					for(int w=0;w<SliceTemp.size();w++) {
						if(isArrayExist(SliceTemp.get(w),SliceArrayList,w)==false)//avoid adding a duplicated entry
						SliceArrayList.add(SliceTemp.get(w));
					}
				}
				else {
					for(int x=0;x<SliceArrayList.size();x++) {
						
						SliceArrayList.get(x).add(inverseKeys[key]);
					}
				}
			}
		}//find all the combinations of patterns, stored in SliceArrayList

	}

	public static void PatternAndTimes(ArrayList<ArrayList<Integer>> SliceArrayList, ArrayList<Integer> location, int[] List, HashMap <String,Integer> results) {	
		for (int y=0;y<SliceArrayList.size();y++)  {	
			int SliceAppearTimes=0;
			for (int x=0;x<location.size();x++){
				int Appear=1;
				
				if(List.length-location.get(x)>=SliceArrayList.get(y).size()) {			
					for(int z=0;z<SliceArrayList.get(y).size();z++) {
						
						if (SliceArrayList.get(y).get(z)==0) {
							continue;
						}						
						else if (SliceArrayList.get(y).get(z)!=List[location.get(x)+z]) {
							//System.out.println(location.get(x)+z);
							Appear=0;
							break;
						}
					}
					SliceAppearTimes+=Appear;
				}
			}	
			results.put(SliceArrayList.get(y).toString(), SliceAppearTimes);
		}
		
	}

	public static String replace0(String output) {
		output=output.replaceAll("[0]", "*");
		output=output.replaceAll("[,\\[\\]\\s]", "");
		return output;
	}
	
	public static void BeautifulMapPrint(HashMap<String,Integer> results) {
		HashMap <String,Integer> resultsForPrint = new HashMap <String,Integer>();
		for (HashMap.Entry<String, Integer> entry : results.entrySet())		{
		    if(entry.getValue()>0)
		    	resultsForPrint.put(replace0(entry.getKey()),entry.getValue());
		}
		ArrayList<String>  keys = new ArrayList<String>(resultsForPrint.keySet());
		for (int i = 0; i < keys.size(); i++) {
		    Object obj = keys.get(i);
		    if (i<keys.size()-1) {
		    	System.out.print(obj+":"+resultsForPrint.get(obj)+", ");
		    }
		    else System.out.print(obj+":"+resultsForPrint.get(obj)+".");
		}	
	}
	
	public static int matchTimes(HashMap<String,Integer> map) {
		int x=0;
		for (HashMap.Entry<String, Integer> entry : map.entrySet()){
			x=x+entry.getValue();
		}
		return x;
	}
	
//	public static HashMap <String,Integer> TestingWithRegex(String[] inputTokens, int pattern) {
//		String toBeProcessed="";
//		String WholePattern=Integer.toString(pattern);
//		WholePattern=WholePattern.replace("0", "[0-9]?");
//		System.out.println("The regex pattern is"+WholePattern);
//		
//		for(int i=0;i<inputTokens.length;i++) {
//			toBeProcessed+=inputTokens[i];			
//		}
//		System.out.println("String to be processed is"+toBeProcessed);
//		
//		Pattern patt=Pattern.compile(WholePattern);
//		Matcher m = patt.matcher(toBeProcessed);
//		HashMap <String,Integer> IamMapYeah = new HashMap <String,Integer>();
	
//		
//		while (m.find()) {  
//	        // Get the starting position of the text
//	        int start = m.start(0);
//	        // Get ending position
//	        int end = m.end(0);
//	        // Print whatever matched.
//	        // Use CharacterIterator.substring(offset, end);
//	        String tmpKey=toBeProcessed.substring(start, end);
//	        
//	        
//	        Object value=IamMapYeah.get(tmpKey);
//	        if (value != null) {
//	        		IamMapYeah.put(tmpKey, IamMapYeah.get(tmpKey) + 1);
//	        } else {
//	        		IamMapYeah.put(tmpKey,1);
//	        }
//		}
//		
//		return IamMapYeah;
//		
//	}
}
